package com.example.sluzbenik_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SluzbenikBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SluzbenikBackApplication.class, args);
	}

}
